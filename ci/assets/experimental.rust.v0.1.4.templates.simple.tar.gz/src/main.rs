fn main() {
    println!("Hello from Appsody!");
}