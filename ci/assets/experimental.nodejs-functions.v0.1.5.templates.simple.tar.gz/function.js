module.exports.url = '/'
module.exports.get = function(req, res, next) { 
    res.send('Hello from Appsody!')
}
