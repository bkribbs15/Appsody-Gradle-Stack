import Application

let app = App()
app.setUpRoutes()
app.run()
