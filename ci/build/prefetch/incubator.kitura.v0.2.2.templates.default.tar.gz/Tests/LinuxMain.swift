import XCTest

@testable import ApplicationTests

XCTMain([
    testCase(KituraStackTests.allTests),
    ])
